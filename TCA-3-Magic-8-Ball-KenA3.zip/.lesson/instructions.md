# Instructions  
## In the JS file ONLY

1. create a variable called magic8Ball and set it equal to an empty object
2. set the line of code below equal to an array of 5 different answers
3. hide the answer element
4. trigger shake animation
5. change image to answer.png
6. fade in the answer
7. set the answer element's text to the answer variable
8. hide the answer element
9. change the image back to question.png
10. add a click handler on the question button that calls the function onClick
